
<?php

include 'db_connect.php';

$tracking = $_GET['tracking'];
$id =$_GET['ID'];

$sql="UPDATE orders SET tracking='$tracking' WHERE id='$id' ";

$to ="index.php?page=orders";
if ($conn->query($sql) === TRUE) {
  $msg= "Record updated successfully";
} else {
  $msg= "Error updating record: " . $conn->error;
}


goto2($to,$msg);
$conn->close();

function goto2 ($to,$Message){
 echo "<script language=\"JavaScript\">alert(\"".$Message."\") \n window.location = \"".$to."\"</script>";
}









 ?>
