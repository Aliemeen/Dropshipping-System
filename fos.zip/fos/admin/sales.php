<div class="container-fluid">
	<div class="card">
		<div class="card-body">
			<table class="table table-bordered">
		<thead>
			<th colspan="6" style="text-align:center;">DROPSHIPPER SALES</th>
			 <tr>

			<th>id</th>
			<th>Name</th>
			<th>Email</th>
			<th>Mobile Number</th>
			<th>Total Sale (MYR)</th>
			<th>Total Commission 10% (MYR) </th>
			</tr>
		</thead>
		<tbody>
			<?php
			$i = 4;
			include 'db_connect.php';
			$qry = $conn->query("SELECT u.user_id,u.first_name,u.last_name,u.email,u.mobile,o.product_id,o.user_id,p.id,p.price,o.qty,sum(p.price*o.qty) as tot
			FROM user_info u
			inner join order_list o
			on u.user_id=o.user_id
			inner join product_list p
			on p.id=o.product_id
			group by u.user_id");
			while($row=$qry->fetch_assoc()):
			 ?>
			 <tr>
			 		<td><?php echo $row['user_id'] ?></td>
			 		<td><?php echo $row['first_name']?> <?php echo $row['last_name']?></td>
			 		<td><?php echo $row['email'] ?></td>
			 		<td><?php echo $row['mobile'] ?></td>
			 		<td><?php echo number_format($row['tot'],2) ?></td>
					<td><?php echo number_format($row['tot']*0.1,2) ?></td>

			 </tr>
			<?php endwhile; ?>
		</tbody>
	</table>
		</div>
	</div>

</div>

<form id="form1" action="updatetrack.php" method="GET">
<div class="container-fluid">
	<div class="card">
		<div class="card-body">
			<table class="table table-bordered">
	<thead>

</thead>
<tbody>


</tbody>
</table>
</div>
</div>
</div>
</form>
<script>
	$('.view_order').click(function(){
		uni_modal('Order','view_order.php?id='+$(this).attr('data-id'))
	})
</script>
