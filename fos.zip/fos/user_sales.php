 <!-- Masthead-->
 <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end mb-4" style="background: #0000002e;">
                    	 <h1 class="text-uppercase text-white font-weight-bold">SALES</h1>
                        <hr class="divider my-4" />
                    </div>

                </div>
            </div>
        </header>

                    <div class="container-fluid">
	<div class="card">
		<div class="card-body">
			<table class="table table-bordered">
		<thead>
			 <tr>

			<th>Order <br>ID</th>
			<th>Customer <br>Name</th>
			<th>Customer <br>Email</th>
			<th>Customer <br>Mobile Number</th>
			<th>Product <br>ID</th>
			<th>Product <br>Name</th>
			<th>Product Price<br> per Unit(MYR)</th>
      <th>Product <br>Quantity</th>
			<th>Total Amount(MYR)</th>
			</tr>
		</thead>
		<tbody>
			<?php
			$i = 1;
      $tosale = 0;
			include 'db_connect.php';
      $qry = $conn->query("SELECT c.id,c.name as cname,c.email as cemail,c.mobile as cmobile,o.order_id,o.product_id as pid,o.user_id,o.qty as pqty,p.id,p.name as pname,p.price as pprice
      FROM orders c inner join order_list o
      on c.id=o.order_id
      inner join product_list p
      on p.id=o.product_id
      where user_id =".$_SESSION['login_user_id']);
			while($row=$qry->fetch_assoc()):
			 ?>
			 <tr>
			 		<td><?php echo $row['order_id'] ?></td>
			 		<td><?php echo $row['cname'] ?></td>
			 		<td><?php echo $row['cemail'] ?></td>
			 		<td><?php echo $row['cmobile'] ?></td>
			 		<td><?php echo $row['pid'] ?></td>
			 		<td><?php echo $row['pname'] ?></td>
          <td><?php echo number_format($row['pprice'],2) ?></td>
          <td><?php echo $row['pqty'] ?></td>
          <td><?php echo number_format($row['pprice']*$row['pqty'],2) ?></td>
			 </tr>
			<?php $tosale += ($row['pprice']*$row['pqty']);
        endwhile; ?>
      <tr>
        <th colspan="8" style="text-align:right;">Total Sales(MYR) :</th>
        <th><?php echo number_format($tosale,2) ?></th>
      </tr>
      <tr>
        <th colspan="8" style="text-align:right;">Total Commission 10%(MYR) :</th>
        <th><?php echo number_format($tosale*0.1,2) ?></th>
      </tr>
		</tbody>
	</table>
		</div>
	</div>

</div>
<script>
	$('.view_order_list').click(function(){
		uni_modal('Order','view_order_list.php?id='+$(this).attr('data-id'))
	})
</script>
