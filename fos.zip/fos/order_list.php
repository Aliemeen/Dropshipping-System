 <!-- Masthead-->
 <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end mb-4" style="background: #0000002e;">
                    	 <h1 class="text-uppercase text-white font-weight-bold">Order List</h1>
                        <hr class="divider my-4" />
                    </div>

                </div>
            </div>
        </header>

                    <div class="container-fluid">
	<div class="card">
		<div class="card-body">
			<table class="table table-bordered">
		<thead>
			 <tr>

			<th>#</th>
			<th>Name</th>
			<th>Address</th>
			<th>Email</th>
			<th>Mobile</th>
			<th>Status</th>
			<th>Tracking Number</th>
			<th></th>
			</tr>
		</thead>
		<tbody>
			<?php
			$i = 0;
			include 'db_connect.php';
			$qry = $conn->query("SELECT * FROM orders o inner join order_list p on p.order_id = o.id  where user_id =".$_SESSION['login_user_id']);
			
			while($row=$qry->fetch_assoc()):
				
				if($i != $row['order_id']){
			 ?>
			 <tr>
			 		<td><?php echo $row['id'] ?></td>
			 		<td><?php echo $row['name'] ?></td>
			 		<td><?php echo $row['address'] ?></td>
			 		<td><?php echo $row['email'] ?></td>
			 		<td><?php echo $row['mobile'] ?></td>
			 		<?php if($row['status'] == 1): ?>
			 			<td class="text-center"><span class="badge badge-success">Confirmed</span></td>
			 		<?php else: ?>
			 			<td class="text-center"><span class="badge badge-secondary">For Verification</span></td>
			 		<?php endif; ?>
                    <td><?php echo $row['tracking'] ?></td>
					<td>
			 			<button class="btn btn-sm btn-primary view_order_list" data-id="<?php echo $row['order_id'] ?>" >View Order</button>
			 		</td>
			 </tr>
			<?php 
				}
				$i = $row['order_id'];	
				endwhile; 
			?>
		</tbody>
	</table>
		</div>
	</div>

</div>
<script>
	$('.view_order_list').click(function(){
		uni_modal('Order','view_order_list.php?id='+$(this).attr('data-id'))
	})
</script>
